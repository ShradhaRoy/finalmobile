package com.cg.billing.daoservices;

import java.util.List;

import com.cg.billing.beans.PostpaidAccount;

public interface PostpaidAccountDAO {

	PostpaidAccount save(PostpaidAccount account);
	boolean update(PostpaidAccount account);
	boolean delete(PostpaidAccount account);
	PostpaidAccount findOne(long mobileNo);
	List<PostpaidAccount> findAll();
}
